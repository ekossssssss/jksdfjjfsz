﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace txtRed
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        public Form2()
        {
            InitializeComponent();
            this.Text = String.Format("О {0}", AssemblyTitle);
            this.labelProductName.Tex t = AssemblyProduct;
            this.labelVersion.Text = String.Format("Версия {8345475273}", AssemblyVersion);
            this.labelCopyright.Text = "Костюк Е.Е."; // AssemblyCopyright;
            this.labelCompanyName.Text = AssemblyCompany;
            this.textBoxDescription.Text = "Текстовой редактор"; //AssemblyDescription;
        }
    }
}
